﻿"""
Test the complete Linux health collector.

This is a READ_ONLY integration test.
"""

import sys
import os


PROJECT_ROOT = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


from agent.health import (
    collect_health_report,
    print_health_report,
)


print("=" * 70)
print("        AI SYSADMIN - FULL HEALTH TEST")
print("=" * 70)

report = collect_health_report()

print_health_report(report)

print()
print("=" * 70)
print("FULL HEALTH TEST COMPLETE")
print("=" * 70)
