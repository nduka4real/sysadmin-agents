﻿import sys
import os


PROJECT_ROOT = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)


if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


from tools.audit import (
    write_audit,
    get_audit_log
)


print("=" * 70)
print("        AI SYSADMIN - AUDIT LOG TEST")
print("=" * 70)


write_audit(
    action="hostname",
    risk="READ_ONLY",
    status="SUCCESS",
    details="Retrieved server hostname."
)


write_audit(
    action="disk",
    risk="READ_ONLY",
    status="SUCCESS",
    details="Retrieved filesystem usage."
)


write_audit(
    action="userdel",
    risk="DESTRUCTIVE",
    status="BLOCKED",
    details="Command rejected by safety engine."
)


print()
print("Audit entries written.")

print()
print("=" * 70)
print("AUDIT LOG")
print("=" * 70)

print(
    get_audit_log()
)


print("=" * 70)
print("AUDIT TEST COMPLETE")
print("=" * 70)
