﻿import sys
import os


PROJECT_ROOT = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)


if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


from tools.safety import (
    validate_command,
    require_safe_command
)


print("=" * 70)
print("        AI SYSADMIN - SAFETY ENGINE TEST")
print("=" * 70)


print()
print("TEST 1: Approved read-only command")

result = validate_command("hostname")

print(result)

if result["allowed"]:
    print("PASS: hostname is allowed.")
else:
    print("FAIL: hostname was blocked.")


print()
print("TEST 2: Unknown command")

result = validate_command("rm")

print(result)

if not result["allowed"]:
    print("PASS: unknown command was blocked.")
else:
    print("FAIL: unknown command was allowed.")


print()
print("TEST 3: Require safe command")

try:

    require_safe_command("disk")

    print("PASS: disk command passed safety validation.")

except Exception as error:

    print("FAIL:", error)


print()
print("TEST 4: Attempt dangerous/unknown command")

try:

    require_safe_command("userdel")

    print("FAIL: dangerous command was allowed.")

except PermissionError as error:

    print("PASS: dangerous command blocked.")
    print(error)


print()
print("=" * 70)
print("SAFETY TEST COMPLETE")
print("=" * 70)
