﻿import sys
import os

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from config import settings
from tools.linux import run_ssh_command
from tools.linux_os import detect_linux_os


print("=" * 70)
print("        AI SYSADMIN - DAY 3 OS DETECTION TEST")
print("=" * 70)

print()
print("Host:", settings.LINUX_HOST)
print("User:", settings.LINUX_USER)


try:

    def run_command(command):
        return run_ssh_command(
            settings.LINUX_HOST,
            settings.LINUX_USER,
            settings.LINUX_PASSWORD,
            command
        )

    result = detect_linux_os(run_command)

    print()
    print("=" * 70)
    print("OS DETECTION RESULT")
    print("=" * 70)

    print("OS ID      :", result["id"])
    print("OS Name    :", result["name"])
    print("Version    :", result["version"])
    print("OS Family  :", result["family"])

    print()

    if result["family"] == "debian":
        print("PASS: Debian-family Linux detected.")

    elif result["family"] == "rhel":
        print("PASS: RHEL-family Linux detected.")

    else:
        print("WARNING: Linux detected but distribution family is unknown.")

except Exception as error:

    print()
    print("FAIL")
    print(type(error).__name__, ":", error)
