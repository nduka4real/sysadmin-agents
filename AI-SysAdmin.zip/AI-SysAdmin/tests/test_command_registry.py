﻿import sys
import os

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from tools.command_registry import (
    get_command,
    list_commands
)

print("=" * 70)
print("        AI SYSADMIN - COMMAND REGISTRY TEST")
print("=" * 70)

commands = list_commands()

print()
print("Approved commands:")
print()

for name, definition in commands.items():
    print(
        f"{name:20} "
        f"{definition['risk']:12} "
        f"{definition['command']}"
    )

print()
print("=" * 70)

try:

    hostname = get_command("hostname")

    print("PASS: hostname is approved.")
    print("Command:", hostname["command"])
    print("Risk   :", hostname["risk"])

except Exception as error:

    print("FAIL:", error)


print()
print("Testing blocked command...")

try:

    get_command("rm")

    print("FAIL: dangerous command was accepted.")

except ValueError:

    print("PASS: unknown command was rejected.")


print()
print("=" * 70)
print("COMMAND REGISTRY TEST COMPLETE")
print("=" * 70)
