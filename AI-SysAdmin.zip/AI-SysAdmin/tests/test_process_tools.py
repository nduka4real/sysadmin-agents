﻿"""
Test Linux Process Investigation Tools.

These tests connect to the configured Linux server
and execute READ_ONLY process investigation commands.
"""

import sys
import os


PROJECT_ROOT = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


from config import settings
from tools.linux import run_ssh_command

from tools.linux_processes import (
    get_top_cpu_processes,
    get_top_memory_processes,
    get_detailed_memory_processes,
    get_detailed_cpu_processes,
    get_top_command,
    get_process_count,
    get_load_average,
    get_zombie_processes,
    get_memory_summary,
    get_cpu_summary,
    get_process_state_summary,
    get_process_tree,
    get_high_memory_processes,
    get_high_cpu_processes,
)


def remote(command):
    """
    Execute a command on the configured Linux server.
    """
    return run_ssh_command(
        settings.LINUX_HOST,
        settings.LINUX_USER,
        settings.LINUX_PASSWORD,
        command
    )


def print_result(title, result):
    """
    Display a test result consistently.
    """
    print()
    print("=" * 70)
    print(title)
    print("=" * 70)
    print(result)


print("=" * 70)
print("        AI SYSADMIN - PROCESS INVESTIGATION TEST")
print("=" * 70)

print_result(
    "1. TOP CPU PROCESSES",
    get_top_cpu_processes(remote, 10)
)

print_result(
    "2. TOP MEMORY PROCESSES",
    get_top_memory_processes(remote, 10)
)

print_result(
    "3. DETAILED MEMORY PROCESSES",
    get_detailed_memory_processes(remote, 15)
)

print_result(
    "4. DETAILED CPU PROCESSES",
    get_detailed_cpu_processes(remote, 15)
)

print_result(
    "5. TOP COMMAND SNAPSHOT",
    get_top_command(remote)
)

print_result(
    "6. PROCESS COUNT",
    get_process_count(remote)
)

print_result(
    "7. LOAD AVERAGE",
    get_load_average(remote)
)

print_result(
    "8. ZOMBIE PROCESSES",
    get_zombie_processes(remote)
)

print_result(
    "9. MEMORY SUMMARY",
    get_memory_summary(remote)
)

print_result(
    "10. CPU SUMMARY",
    get_cpu_summary(remote)
)

print_result(
    "11. PROCESS STATE SUMMARY",
    get_process_state_summary(remote)
)

print_result(
    "12. PROCESS TREE / PROCESS OVERVIEW",
    get_process_tree(remote, 20)
)

print_result(
    "13. PROCESSES USING 10% OR MORE MEMORY",
    get_high_memory_processes(
        remote,
        threshold=10,
        lines=20
    )
)

print_result(
    "14. PROCESSES USING 50% OR MORE CPU",
    get_high_cpu_processes(
        remote,
        threshold=50,
        lines=20
    )
)

print()
print("=" * 70)
print("PROCESS INVESTIGATION TEST COMPLETE")
print("=" * 70)
