﻿"""
AI SysAdmin - Diagnostic Analyzer Test

Runs the complete READ_ONLY health collection and then
passes the resulting evidence into the deterministic analyzer.
"""

import sys
import os


PROJECT_ROOT = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)


if PROJECT_ROOT not in sys.path:
    sys.path.insert(
        0,
        PROJECT_ROOT
    )


from agent.health import collect_health_report
from agent.analyzer import (
    analyze_health_report,
    print_analysis,
)


print("=" * 70)
print("        AI SYSADMIN - DIAGNOSTIC ANALYZER TEST")
print("=" * 70)


print()
print("STEP 1: Collecting server evidence...")

report = collect_health_report()


print()
print("STEP 2: Analyzing collected evidence...")

analysis = analyze_health_report(
    report
)


print()
print("STEP 3: Diagnostic analysis")

print_analysis(
    analysis
)


print()
print("=" * 70)
print("DIAGNOSTIC ANALYZER TEST COMPLETE")
print("=" * 70)
