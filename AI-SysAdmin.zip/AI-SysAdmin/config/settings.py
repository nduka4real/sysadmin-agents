﻿import os
from dotenv import load_dotenv

# Get the project root:
# C:\AI-SysAdmin
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Load the .env file from the project root
ENV_FILE = os.path.join(PROJECT_ROOT, ".env")
load_dotenv(ENV_FILE)

# Linux server connection settings
LINUX_HOST = os.getenv("LINUX_HOST")
LINUX_USER = os.getenv("LINUX_USER")
LINUX_PASSWORD = os.getenv("LINUX_PASSWORD")
