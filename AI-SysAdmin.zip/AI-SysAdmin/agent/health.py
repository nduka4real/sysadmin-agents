﻿"""
AI SysAdmin - Linux Health Collector
Day 3

Combines the individual Linux investigation tools into
one structured server health report.

IMPORTANT:
This module is READ_ONLY.

It does not:
- install packages
- remove packages
- stop services
- restart services
- kill processes
- modify firewall rules
- modify users
- modify files
- reboot the server
"""


from config import settings

from tools.linux import run_ssh_command
from tools.linux_os import detect_linux_os
from tools.linux_processes import (
    get_top_cpu_processes,
    get_top_memory_processes,
    get_process_count,
    get_load_average,
    get_zombie_processes,
    get_memory_summary,
    get_cpu_summary,
)

from tools.linux_logs import (
    get_journal_errors,
    get_journal_warnings,
    get_auth_logs,
)

from tools.command_registry import get_command
from tools.audit import write_audit


def remote(command):
    """
    Execute a read-only command on the configured Linux server.
    """

    return run_ssh_command(
        settings.LINUX_HOST,
        settings.LINUX_USER,
        settings.LINUX_PASSWORD,
        command
    )


def collect_command(command_name):
    """
    Execute a command from the approved command registry.

    This provides an additional safety layer:
    the health collector cannot execute arbitrary commands.
    """

    command_definition = get_command(command_name)

    result = remote(
        command_definition["command"]
    )

    write_audit(
        action=command_name,
        risk=command_definition["risk"],
        status=(
            "SUCCESS"
            if result.get("success")
            else "FAILED"
        ),
        details=command_definition["description"]
    )

    return result


def collect_os_information():
    """
    Detect the Linux operating system.
    """

    return detect_linux_os(remote)


def collect_common_health():
    """
    Collect common Linux health information.
    """

    return {
        "hostname": collect_command("hostname"),
        "uptime": collect_command("uptime"),
        "memory": collect_command("memory"),
        "disk": collect_command("disk"),
        "cpu": collect_command("cpu"),
        "network": collect_command("network"),
        "ports": collect_command("ports"),
        "failed_services": collect_command(
            "failed_services"
        ),
    }


def collect_process_health():
    """
    Collect process and load information.
    """

    return {
        "top_cpu": get_top_cpu_processes(
            remote,
            lines=10
        ),

        "top_memory": get_top_memory_processes(
            remote,
            lines=10
        ),

        "process_count": get_process_count(
            remote
        ),

        "load_average": get_load_average(
            remote
        ),

        "zombie_processes": get_zombie_processes(
            remote
        ),

        "memory_summary": get_memory_summary(
            remote
        ),

        "cpu_summary": get_cpu_summary(
            remote
        ),
    }


def collect_log_health():
    """
    Collect recent journal and authentication information.
    """

    return {
        "journal_errors": get_journal_errors(
            remote,
            lines=50
        ),

        "journal_warnings": get_journal_warnings(
            remote,
            lines=50
        ),

        "authentication_logs": get_auth_logs(
            remote,
            lines=50
        ),
    }


def collect_security_health(os_information):
    """
    Collect OS-specific security information.

    Debian/Ubuntu:
        UFW

    RHEL-family:
        firewalld
        SELinux
    """

    family = os_information.get(
        "family",
        "unknown"
    )

    security = {
        "family": family
    }

    if family == "debian":

        security["firewall"] = collect_command(
            "ufw"
        )

        security["selinux"] = {
            "status": "NOT_APPLICABLE",
            "reason": (
                "SELinux collection is not "
                "enabled for Debian-family systems."
            )
        }

    elif family == "rhel":

        security["firewall"] = collect_command(
            "firewall"
        )

        security["firewall_rules"] = collect_command(
            "firewall_rules"
        )

        security["selinux"] = collect_command(
            "selinux"
        )

        security["selinux_status"] = collect_command(
            "selinux_status"
        )

    else:

        security["firewall"] = {
            "status": "UNKNOWN",
            "reason": (
                "Unsupported or unknown Linux family."
            )
        }

        security["selinux"] = {
            "status": "UNKNOWN",
            "reason": (
                "Unsupported or unknown Linux family."
            )
        }

    return security


def collect_health_report():
    """
    Build the complete read-only Linux health report.
    """

    print()
    print("=" * 70)
    print("AI SYSADMIN - SERVER HEALTH COLLECTION")
    print("=" * 70)

    print()
    print("Detecting operating system...")

    os_information = collect_os_information()

    print(
        f"Detected: "
        f"{os_information.get('name', 'Unknown')} "
        f"{os_information.get('version', '')}"
    )

    print()
    print("Collecting common system health...")

    common = collect_common_health()

    print("Collecting process information...")

    processes = collect_process_health()

    print("Collecting logs and journal information...")

    logs = collect_log_health()

    print("Collecting security information...")

    security = collect_security_health(
        os_information
    )

    report = {
        "server": {
            "host": settings.LINUX_HOST,
            "user": settings.LINUX_USER,
        },

        "operating_system": os_information,

        "system": common,

        "processes": processes,

        "logs": logs,

        "security": security,
    }

    print()
    print("=" * 70)
    print("SERVER HEALTH COLLECTION COMPLETE")
    print("=" * 70)

    return report


def print_health_report(report):
    """
    Print a human-readable summary of the health report.
    """

    print()
    print("=" * 70)
    print("AI SYSADMIN - HEALTH REPORT")
    print("=" * 70)

    os_info = report["operating_system"]

    print()
    print("OPERATING SYSTEM")
    print("-" * 70)

    print(
        "Name:",
        os_info.get("name")
    )

    print(
        "Version:",
        os_info.get("version")
    )

    print(
        "Family:",
        os_info.get("family")
    )

    print()
    print("HOSTNAME")
    print("-" * 70)

    print(
        report["system"]["hostname"]
    )

    print()
    print("UPTIME")
    print("-" * 70)

    print(
        report["system"]["uptime"]
    )

    print()
    print("MEMORY")
    print("-" * 70)

    print(
        report["system"]["memory"]
    )

    print()
    print("DISK")
    print("-" * 70)

    print(
        report["system"]["disk"]
    )

    print()
    print("LOAD AVERAGE")
    print("-" * 70)

    print(
        report["processes"]["load_average"]
    )

    print()
    print("PROCESS COUNT")
    print("-" * 70)

    print(
        report["processes"]["process_count"]
    )

    print()
    print("TOP CPU PROCESSES")
    print("-" * 70)

    print(
        report["processes"]["top_cpu"]
    )

    print()
    print("TOP MEMORY PROCESSES")
    print("-" * 70)

    print(
        report["processes"]["top_memory"]
    )

    print()
    print("ZOMBIE PROCESSES")
    print("-" * 70)

    print(
        report["processes"]["zombie_processes"]
    )

    print()
    print("FAILED SERVICES")
    print("-" * 70)

    print(
        report["system"]["failed_services"]
    )

    print()
    print("JOURNAL ERRORS")
    print("-" * 70)

    print(
        report["logs"]["journal_errors"]
    )

    print()
    print("JOURNAL WARNINGS")
    print("-" * 70)

    print(
        report["logs"]["journal_warnings"]
    )

    print()
    print("SECURITY")
    print("-" * 70)

    print(
        report["security"]
    )

    print()
    print("=" * 70)
    print("END OF HEALTH REPORT")
    print("=" * 70)
