﻿"""
AI SysAdmin - Diagnostic Reasoning Layer
Day 3

This module analyzes the structured health report collected from
a Linux server.

IMPORTANT:
    This is a deterministic evidence-analysis layer.

It does NOT:
    - modify the server
    - restart services
    - kill processes
    - install packages
    - modify firewall rules
    - modify users
    - modify files
    - reboot the server

Its job is to transform raw command results into structured findings
that can later be supplied to a local LLM such as Qwen3.

The analyzer deliberately distinguishes:

    FACT
    WARNING
    NOISE / EXPECTED EVENT
    HYPOTHESIS
    RECOMMENDATION
    PRIVILEGE ISSUE

The LLM should reason over this evidence rather than inventing
facts that were never collected.
"""


from typing import Any, Dict, List


# ================================================================
# RESULT HELPERS
# ================================================================

def result_text(result: Any) -> str:
    """
    Extract textual command output from a tool result.

    The current SSH layer normally returns dictionaries such as:

        {
            "success": True,
            "output": "...",
            "error": "..."
        }

    This helper also tolerates stdout/result fields so the analyzer
    remains compatible with future versions of the tool layer.
    """

    if result is None:
        return ""

    if isinstance(result, str):
        return result

    if isinstance(result, dict):

        for key in (
            "output",
            "stdout",
            "result",
            "text",
        ):
            value = result.get(key)

            if value is not None:
                return str(value)

    return str(result)


def result_error(result: Any) -> str:
    """
    Extract command stderr/error information.
    """

    if not isinstance(result, dict):
        return ""

    error = result.get("error")

    if error is None:
        return ""

    return str(error).strip()


def command_succeeded(result: Any) -> bool:
    """
    Determine whether the actual command appears to have succeeded.

    IMPORTANT:

    SSH transport success is NOT automatically treated as command
    success.

    A command can successfully connect over SSH and still fail because
    of permissions, missing commands, invalid arguments, etc.
    """

    if result is None:
        return False

    if not isinstance(result, dict):
        return True

    error = result_error(result)

    if error:
        return False

    if "success" in result:
        return bool(result.get("success"))

    return True


def is_privilege_error(result: Any) -> bool:
    """
    Detect common privilege-related failures.
    """

    text = (
        result_text(result)
        + "\n"
        + result_error(result)
    ).lower()

    patterns = [
        "you need to be root",
        "must be root",
        "permission denied",
        "operation not permitted",
        "access denied",
        "not permitted",
        "requires root",
        "requires administrator",
        "sudo",
    ]

    return any(
        pattern in text
        for pattern in patterns
    )


def add_finding(
    collection: List[Dict[str, Any]],
    finding_type: str,
    title: str,
    description: str,
    confidence: str,
    evidence: List[str],
    severity: str = "INFO",
):
    """
    Add a normalized finding to a collection.
    """

    collection.append(
        {
            "type": finding_type,
            "severity": severity,
            "title": title,
            "description": description,
            "confidence": confidence,
            "evidence": evidence,
        }
    )


# ================================================================
# FACT ANALYSIS
# ================================================================

def analyze_operating_system(report, facts):
    os_info = report.get(
        "operating_system",
        {}
    )

    name = os_info.get(
        "name",
        "Unknown"
    )

    version = os_info.get(
        "version",
        "Unknown"
    )

    family = os_info.get(
        "family",
        "unknown"
    )

    add_finding(
        facts,
        "FACT",
        "Operating system detected",
        f"{name} {version} was detected as a {family}-family Linux system.",
        "HIGH",
        [
            "operating_system.name",
            "operating_system.version",
            "operating_system.family",
        ],
    )


def analyze_hostname(report, facts):
    result = report.get(
        "system",
        {}
    ).get(
        "hostname"
    )

    text = result_text(result).strip()

    if not text:
        return

    add_finding(
        facts,
        "FACT",
        "Server hostname",
        f"The server reported hostname '{text}'.",
        "HIGH",
        [
            "system.hostname"
        ],
    )


def analyze_memory(report, facts, warnings):
    result = report.get(
        "system",
        {}
    ).get(
        "memory"
    )

    text = result_text(result)

    if not text:
        return

    add_finding(
        facts,
        "FACT",
        "Memory statistics collected",
        "The server returned memory and swap statistics.",
        "HIGH",
        [
            "system.memory"
        ],
    )

    lower = text.lower()

    if "swap" in lower:
        add_finding(
            facts,
            "FACT",
            "Swap information available",
            "The memory report includes swap statistics.",
            "HIGH",
            [
                "system.memory"
            ],
        )


def analyze_disk(report, facts, warnings):
    result = report.get(
        "system",
        {}
    ).get(
        "disk"
    )

    text = result_text(result)

    if not text:
        return

    add_finding(
        facts,
        "FACT",
        "Filesystem usage collected",
        "Filesystem capacity and usage information was collected.",
        "HIGH",
        [
            "system.disk"
        ],
    )

    # Look for obviously high filesystem percentages.
    for line in text.splitlines():

        parts = line.split()

        if len(parts) < 5:
            continue

        usage = parts[-2]

        if not usage.endswith("%"):
            continue

        try:
            percentage = int(
                usage.rstrip("%")
            )
        except ValueError:
            continue

        filesystem = parts[-1]

        if percentage >= 90:

            add_finding(
                warnings,
                "WARNING",
                "Filesystem critically full",
                (
                    f"Filesystem {filesystem} is "
                    f"reported at {percentage}% usage."
                ),
                "HIGH",
                [
                    "system.disk"
                ],
                severity="HIGH",
            )

        elif percentage >= 80:

            add_finding(
                warnings,
                "WARNING",
                "Filesystem usage is high",
                (
                    f"Filesystem {filesystem} is "
                    f"reported at {percentage}% usage."
                ),
                "HIGH",
                [
                    "system.disk"
                ],
                severity="MEDIUM",
            )


def analyze_failed_services(report, facts, warnings):
    result = report.get(
        "system",
        {}
    ).get(
        "failed_services"
    )

    text = result_text(result).strip()

    if not text:
        return

    lower = text.lower()

    if (
        "0 loaded units listed" in lower
        or "0 loaded unit listed" in lower
    ):

        add_finding(
            facts,
            "FACT",
            "No failed systemd units reported",
            "systemd reported zero loaded failed units.",
            "HIGH",
            [
                "system.failed_services"
            ],
        )

        return

    add_finding(
        warnings,
        "WARNING",
        "Failed systemd units reported",
        (
            "The systemd failure report contains entries that "
            "require investigation."
        ),
        "HIGH",
        [
            "system.failed_services"
        ],
        severity="MEDIUM",
    )


# ================================================================
# PROCESS ANALYSIS
# ================================================================

def analyze_processes(report, facts, warnings):
    processes = report.get(
        "processes",
        {}
    )

    process_count = processes.get(
        "process_count"
    )

    load_average = processes.get(
        "load_average"
    )

    top_cpu = processes.get(
        "top_cpu"
    )

    top_memory = processes.get(
        "top_memory"
    )

    zombies = processes.get(
        "zombie_processes"
    )

    if process_count:
        add_finding(
            facts,
            "FACT",
            "Process count collected",
            (
                "The server returned its current process count."
            ),
            "HIGH",
            [
                "processes.process_count"
            ],
        )

    if load_average:
        load_text = result_text(
            load_average
        ).strip()

        add_finding(
            facts,
            "FACT",
            "Load average collected",
            f"Linux reported load information: {load_text}",
            "HIGH",
            [
                "processes.load_average"
            ],
        )

    if top_cpu:
        add_finding(
            facts,
            "FACT",
            "Top CPU processes collected",
            (
                "A read-only process listing sorted by CPU "
                "usage was collected."
            ),
            "HIGH",
            [
                "processes.top_cpu"
            ],
        )

    if top_memory:
        add_finding(
            facts,
            "FACT",
            "Top memory processes collected",
            (
                "A read-only process listing sorted by memory "
                "usage was collected."
            ),
            "HIGH",
            [
                "processes.top_memory"
            ],
        )

    zombie_text = result_text(
        zombies
    ).strip()

    if zombie_text:

        add_finding(
            warnings,
            "WARNING",
            "Zombie processes detected",
            (
                "The process investigation returned one or more "
                "zombie processes."
            ),
            "HIGH",
            [
                "processes.zombie_processes"
            ],
            severity="MEDIUM",
        )

    else:

        add_finding(
            facts,
            "FACT",
            "No zombie processes reported",
            (
                "The zombie-process check returned no zombie "
                "process entries."
            ),
            "HIGH",
            [
                "processes.zombie_processes"
            ],
        )


# ================================================================
# LOG ANALYSIS
# ================================================================

def analyze_journal(report, warnings, noise):
    logs = report.get(
        "logs",
        {}
    )

    errors = logs.get(
        "journal_errors"
    )

    error_text = result_text(
        errors
    ).strip()

    if error_text:

        add_finding(
            warnings,
            "WARNING",
            "Journal contains error-priority events",
            (
                "The current journal query returned error-priority "
                "events. These events require context before they "
                "are treated as root causes."
            ),
            "HIGH",
            [
                "logs.journal_errors"
            ],
            severity="MEDIUM",
        )

        lower = error_text.lower()

        # --------------------------------------------------------
        # Common desktop / VM noise
        # --------------------------------------------------------

        noise_patterns = [
            (
                "pulseaudio",
                "PulseAudio-related messages may be desktop audio noise."
            ),
            (
                "pipewire",
                "PipeWire-related messages may be desktop audio/session noise."
            ),
            (
                "alsa",
                "ALSA-related messages may be desktop audio noise."
            ),
            (
                "gnome",
                "GNOME session messages may be desktop-session noise."
            ),
            (
                "dbus",
                "D-Bus session messages may be desktop-session noise."
            ),
            (
                "tracker",
                "Tracker metadata messages may be desktop indexing noise."
            ),
        ]

        for pattern, explanation in noise_patterns:

            if pattern in lower:

                add_finding(
                    noise,
                    "NOISE",
                    f"Possible desktop/session noise: {pattern}",
                    explanation,
                    "MEDIUM",
                    [
                        "logs.journal_errors"
                    ],
                )


def analyze_kernel_events(report, warnings, noise):
    logs = report.get(
        "logs",
        {}
    )

    errors = logs.get(
        "journal_errors"
    )

    text = result_text(
        errors
    )

    lower = text.lower()

    # Historical kernel soft lockups are important, but must not
    # automatically be described as a current active failure.
    if (
        "soft lockup" in lower
        or "watchdog" in lower
    ):

        add_finding(
            warnings,
            "WARNING",
            "Kernel/watchdog events appear in the journal",
            (
                "Kernel watchdog or soft-lockup messages were found "
                "in the collected journal evidence. Their timestamps "
                "must be checked before deciding whether the condition "
                "is current."
            ),
            "HIGH",
            [
                "logs.journal_errors"
            ],
            severity="MEDIUM",
        )

        add_finding(
            noise,
            "NOISE",
            "Historical kernel events require timestamp correlation",
            (
                "A historical kernel event should not automatically "
                "be treated as a currently active server failure."
            ),
            "HIGH",
            [
                "logs.journal_errors"
            ],
        )


# ================================================================
# SECURITY / PRIVILEGE ANALYSIS
# ================================================================

def analyze_security(report, facts, warnings, privilege_issues):
    security = report.get(
        "security",
        {}
    )

    family = security.get(
        "family",
        "unknown"
    )

    firewall = security.get(
        "firewall"
    )

    if firewall is not None:

        if is_privilege_error(firewall):

            add_finding(
                privilege_issues,
                "PRIVILEGE_ISSUE",
                "Firewall status could not be fully verified",
                (
                    "The firewall command reached the server but "
                    "the command reported that elevated privileges "
                    "are required."
                ),
                "HIGH",
                [
                    "security.firewall"
                ],
                severity="MEDIUM",
            )

        elif command_succeeded(firewall):

            add_finding(
                facts,
                "FACT",
                "Firewall query completed",
                (
                    f"The {family}-family firewall query returned "
                    "without an error."
                ),
                "HIGH",
                [
                    "security.firewall"
                ],
            )

    selinux = security.get(
        "selinux"
    )

    if family == "debian":

        add_finding(
            facts,
            "FACT",
            "SELinux marked not applicable",
            (
                "The health collector correctly marked SELinux "
                "as not applicable for this Debian-family host."
            ),
            "HIGH",
            [
                "security.selinux"
            ],
        )

    elif family == "rhel" and selinux is not None:

        if is_privilege_error(selinux):

            add_finding(
                privilege_issues,
                "PRIVILEGE_ISSUE",
                "SELinux status requires additional privilege",
                (
                    "SELinux status collection reported a "
                    "permission-related problem."
                ),
                "HIGH",
                [
                    "security.selinux"
                ],
                severity="MEDIUM",
            )

        elif command_succeeded(selinux):

            add_finding(
                facts,
                "FACT",
                "SELinux status collected",
                "SELinux status was successfully queried.",
                "HIGH",
                [
                    "security.selinux"
                ],
            )


# ================================================================
# AUTHENTICATION LOG ANALYSIS
# ================================================================

def analyze_auth_logs(report, facts, warnings, privilege_issues):
    logs = report.get(
        "logs",
        {}
    )

    result = logs.get(
        "authentication_logs"
    )

    if result is None:
        return

    if is_privilege_error(result):

        add_finding(
            privilege_issues,
            "PRIVILEGE_ISSUE",
            "Authentication logs could not be fully read",
            (
                "The authentication-log collection encountered "
                "a privilege-related limitation."
            ),
            "HIGH",
            [
                "logs.authentication_logs"
            ],
            severity="MEDIUM",
        )

        return

    text = result_text(
        result
    ).strip()

    if not text:
        return

    add_finding(
        facts,
        "FACT",
        "Authentication logs collected",
        (
            "Authentication-related log evidence was returned "
            "by the server."
        ),
        "HIGH",
        [
            "logs.authentication_logs"
        ],
    )

    lower = text.lower()

    failed_patterns = [
        "failed password",
        "authentication failure",
        "invalid user",
        "failed login",
    ]

    if any(
        pattern in lower
        for pattern in failed_patterns
    ):

        add_finding(
            warnings,
            "WARNING",
            "Authentication failures appear in logs",
            (
                "Authentication-log evidence contains strings "
                "associated with failed authentication attempts. "
                "The events should be correlated with timestamps, "
                "source addresses, and expected administrative activity."
            ),
            "MEDIUM",
            [
                "logs.authentication_logs"
            ],
            severity="MEDIUM",
        )


# ================================================================
# NETWORK ANALYSIS
# ================================================================

def analyze_network(report, facts):
    system = report.get(
        "system",
        {}
    )

    network = system.get(
        "network"
    )

    ports = system.get(
        "ports"
    )

    if network:

        add_finding(
            facts,
            "FACT",
            "Network interface information collected",
            (
                "Network interface information was collected "
                "from the server."
            ),
            "HIGH",
            [
                "system.network"
            ],
        )

    if ports:

        add_finding(
            facts,
            "FACT",
            "Listening-port information collected",
            (
                "The server's listening sockets were collected "
                "for investigation."
            ),
            "HIGH",
            [
                "system.ports"
            ],
        )


# ================================================================
# COMMAND FAILURE ANALYSIS
# ================================================================

def analyze_command_failures(report, warnings, privilege_issues):
    """
    Recursively inspect the report for command results containing
    errors.

    This catches failures that the health collector may have stored
    inside nested structures.
    """

    def walk(
        value,
        path=""
    ):

        if isinstance(value, dict):

            if (
                "error" in value
                and value.get("error")
            ):

                error = str(
                    value.get("error")
                ).strip()

                if is_privilege_error(value):

                    add_finding(
                        privilege_issues,
                        "PRIVILEGE_ISSUE",
                        "Command encountered a privilege limitation",
                        error,
                        "HIGH",
                        [
                            path or "report"
                        ],
                        severity="MEDIUM",
                    )

                else:

                    add_finding(
                        warnings,
                        "WARNING",
                        "Command returned an error",
                        error,
                        "HIGH",
                        [
                            path or "report"
                        ],
                        severity="MEDIUM",
                    )

            for key, child in value.items():

                child_path = (
                    f"{path}.{key}"
                    if path
                    else key
                )

                walk(
                    child,
                    child_path
                )

        elif isinstance(value, list):

            for index, child in enumerate(value):

                walk(
                    child,
                    f"{path}[{index}]"
                )

    walk(report)


# ================================================================
# RECOMMENDATIONS
# ================================================================

def generate_recommendations(
    report,
    warnings,
    privilege_issues
):
    recommendations = []

    warning_titles = {
        item["title"]
        for item in warnings
    }

    privilege_titles = {
        item["title"]
        for item in privilege_issues
    }

    if (
        "Filesystem critically full"
        in warning_titles
        or "Filesystem usage is high"
        in warning_titles
    ):

        recommendations.append(
            {
                "command_name": "disk",
                "reason": (
                    "Recheck filesystem usage and identify "
                    "which filesystem is approaching capacity."
                ),
                "risk": "READ_ONLY",
                "confidence": "HIGH",
                "evidence": [
                    "system.disk"
                ],
            }
        )

    if (
        "Failed systemd units reported"
        in warning_titles
    ):

        recommendations.append(
            {
                "command_name": "failed_services",
                "reason": (
                    "Inspect failed systemd units and then "
                    "retrieve service-specific journal evidence."
                ),
                "risk": "READ_ONLY",
                "confidence": "HIGH",
                "evidence": [
                    "system.failed_services"
                ],
            }
        )

    if (
        "Zombie processes detected"
        in warning_titles
    ):

        recommendations.append(
            {
                "command_name": "top_snapshot",
                "reason": (
                    "Capture a broader read-only process snapshot "
                    "to correlate the zombie process condition."
                ),
                "risk": "READ_ONLY",
                "confidence": "HIGH",
                "evidence": [
                    "processes.zombie_processes"
                ],
            }
        )

    if (
        "Journal contains error-priority events"
        in warning_titles
    ):

        recommendations.append(
            {
                "command_name": "journal_errors",
                "reason": (
                    "Review recent error-priority journal entries "
                    "and correlate them with timestamps."
                ),
                "risk": "READ_ONLY",
                "confidence": "HIGH",
                "evidence": [
                    "logs.journal_errors"
                ],
            }
        )

    if (
        "Kernel/watchdog events appear in the journal"
        in warning_titles
    ):

        recommendations.append(
            {
                "command_name": "kernel_errors",
                "reason": (
                    "Inspect kernel warning/error messages and "
                    "determine whether the events are current or historical."
                ),
                "risk": "READ_ONLY",
                "confidence": "HIGH",
                "evidence": [
                    "logs.journal_errors"
                ],
            }
        )

    if (
        "Authentication failures appear in logs"
        in warning_titles
    ):

        recommendations.append(
            {
                "command_name": "auth_logs",
                "reason": (
                    "Review authentication events and correlate "
                    "failed attempts with timestamps and source addresses."
                ),
                "risk": "READ_ONLY",
                "confidence": "MEDIUM",
                "evidence": [
                    "logs.authentication_logs"
                ],
            }
        )

    if privilege_titles:

        recommendations.append(
            {
                "command_name": "hostname",
                "reason": (
                    "Confirm the target server before repeating "
                    "privileged diagnostic collection through an "
                    "approved elevated account."
                ),
                "risk": "READ_ONLY",
                "confidence": "HIGH",
                "evidence": [
                    "privilege_issues"
                ],
            }
        )

    # ------------------------------------------------------------
    # Process investigation should be available when the server
    # has process and load evidence, even if no warning has yet
    # been generated.
    # ------------------------------------------------------------

    if report.get("processes"):

        recommendations.append(
            {
                "command_name": "top_cpu_processes",
                "reason": (
                    "Inspect processes consuming the most CPU "
                    "before making any performance conclusion."
                ),
                "risk": "READ_ONLY",
                "confidence": "HIGH",
                "evidence": [
                    "processes.top_cpu"
                ],
            }
        )

        recommendations.append(
            {
                "command_name": "top_memory_processes",
                "reason": (
                    "Inspect processes consuming the most memory "
                    "before concluding that the server has memory pressure."
                ),
                "risk": "READ_ONLY",
                "confidence": "HIGH",
                "evidence": [
                    "processes.top_memory"
                ],
            }
        )

    return recommendations


# ================================================================
# OVERALL HEALTH ASSESSMENT
# ================================================================

def calculate_overall_status(
    facts,
    warnings,
    noise,
    privilege_issues
):
    """
    Produce a cautious status.

    The analyzer intentionally does NOT say:

        "healthy"

    simply because commands returned successfully.

    Status values:

        NORMAL
        ATTENTION_REQUIRED
        INVESTIGATION_REQUIRED
        INCONCLUSIVE
    """

    high_warnings = [
        item
        for item in warnings
        if item.get("severity") == "HIGH"
    ]

    if privilege_issues and not warnings:

        return {
            "status": "INCONCLUSIVE",
            "reason": (
                "Some diagnostic evidence could not be fully "
                "collected because of privilege limitations."
            ),
        }

    if high_warnings:

        return {
            "status": "INVESTIGATION_REQUIRED",
            "reason": (
                "One or more high-severity findings require "
                "further investigation."
            ),
        }

    if warnings:

        return {
            "status": "ATTENTION_REQUIRED",
            "reason": (
                "The server returned conditions worth investigating, "
                "but the evidence does not by itself establish a root cause."
            ),
        }

    if privilege_issues:

        return {
            "status": "INCONCLUSIVE",
            "reason": (
                "No major warning was established, but some evidence "
                "could not be fully collected because of privilege limitations."
            ),
        }

    return {
        "status": "NORMAL",
        "reason": (
            "No warning-level condition was identified by the "
            "current deterministic checks. This is not a guarantee "
            "that the server has no problems."
        ),
    }


# ================================================================
# MAIN ANALYZER
# ================================================================

def analyze_health_report(report):
    """
    Analyze a health report and return structured diagnostic evidence.
    """

    facts = []
    warnings = []
    noise = []
    privilege_issues = []

    analyze_operating_system(
        report,
        facts
    )

    analyze_hostname(
        report,
        facts
    )

    analyze_memory(
        report,
        facts,
        warnings
    )

    analyze_disk(
        report,
        facts,
        warnings
    )

    analyze_failed_services(
        report,
        facts,
        warnings
    )

    analyze_processes(
        report,
        facts,
        warnings
    )

    analyze_journal(
        report,
        warnings,
        noise
    )

    analyze_kernel_events(
        report,
        warnings,
        noise
    )

    analyze_security(
        report,
        facts,
        warnings,
        privilege_issues
    )

    analyze_auth_logs(
        report,
        facts,
        warnings,
        privilege_issues
    )

    analyze_network(
        report,
        facts
    )

    analyze_command_failures(
        report,
        warnings,
        privilege_issues
    )

    recommendations = generate_recommendations(
        report,
        warnings,
        privilege_issues
    )

    # ------------------------------------------------------------
    # Hypotheses
    #
    # These are NOT conclusions.
    # They are possible explanations that must be investigated.
    # ------------------------------------------------------------

    hypotheses = []

    if any(
        item["title"] == "Filesystem usage is high"
        or item["title"] == "Filesystem critically full"
        for item in warnings
    ):

        hypotheses.append(
            {
                "type": "HYPOTHESIS",
                "title": "Possible disk-capacity pressure",
                "description": (
                    "High filesystem usage could contribute to "
                    "application failures, logging problems, or "
                    "service instability."
                ),
                "confidence": "MEDIUM",
                "evidence": [
                    "system.disk"
                ],
            }
        )

    if any(
        item["title"] == "Zombie processes detected"
        for item in warnings
    ):

        hypotheses.append(
            {
                "type": "HYPOTHESIS",
                "title": "Possible parent-process issue",
                "description": (
                    "Zombie processes may indicate that one or more "
                    "parent processes are not correctly collecting "
                    "child-process exit states."
                ),
                "confidence": "MEDIUM",
                "evidence": [
                    "processes.zombie_processes"
                ],
            }
        )

    if any(
        item["title"] == "Kernel/watchdog events appear in the journal"
        for item in warnings
    ):

        hypotheses.append(
            {
                "type": "HYPOTHESIS",
                "title": "Possible historical or intermittent kernel pressure",
                "description": (
                    "Kernel watchdog or soft-lockup events could indicate "
                    "historical CPU scheduling, virtualization, hardware, "
                    "or kernel-related pressure. Timestamp correlation is "
                    "required before treating this as a current problem."
                ),
                "confidence": "LOW",
                "evidence": [
                    "logs.journal_errors"
                ],
            }
        )

    if any(
        item["title"] == "Authentication failures appear in logs"
        for item in warnings
    ):

        hypotheses.append(
            {
                "type": "HYPOTHESIS",
                "title": "Possible authentication activity requiring review",
                "description": (
                    "Repeated failed authentication events could represent "
                    "normal administrative mistakes, automated service "
                    "activity, misconfiguration, or unauthorized attempts. "
                    "The collected evidence does not establish which."
                ),
                "confidence": "LOW",
                "evidence": [
                    "logs.authentication_logs"
                ],
            }
        )

    overall = calculate_overall_status(
        facts,
        warnings,
        noise,
        privilege_issues
    )

    return {
        "analyzer": {
            "name": "AI SysAdmin Diagnostic Analyzer",
            "version": "1.0",
            "mode": "DETERMINISTIC_EVIDENCE_ANALYSIS",
            "read_only": True,
        },

        "overall": overall,

        "facts": facts,

        "warnings": warnings,

        "noise_expected_events": noise,

        "potential_causes": hypotheses,

        "recommended_investigations": recommendations,

        "privilege_issues": privilege_issues,

        "evidence_policy": {
            "facts_require_collected_evidence": True,
            "hypotheses_are_not_conclusions": True,
            "warnings_require_supporting_evidence": True,
            "noise_is_not_automatically_failure": True,
            "privilege_limitations_must_be_reported": True,
        },
    }


# ================================================================
# HUMAN-READABLE OUTPUT
# ================================================================

def print_section(
    title,
    items
):
    print()
    print("=" * 70)
    print(title)
    print("=" * 70)

    if not items:

        print("None identified.")

        return

    for index, item in enumerate(
        items,
        start=1
    ):

        print()
        print(
            f"{index}. "
            f"{item.get('title', 'Untitled')}"
        )

        print(
            "   Type:",
            item.get("type")
        )

        if "severity" in item:
            print(
                "   Severity:",
                item.get("severity")
            )

        print(
            "   Confidence:",
            item.get("confidence")
        )

        print(
            "   Description:",
            item.get("description")
        )

        evidence = item.get(
            "evidence",
            []
        )

        if evidence:

            print(
                "   Evidence:",
                ", ".join(evidence)
            )


def print_analysis(analysis):
    """
    Print a human-readable diagnostic analysis.
    """

    print()
    print("=" * 70)
    print("AI SYSADMIN - DIAGNOSTIC ANALYSIS")
    print("=" * 70)

    overall = analysis.get(
        "overall",
        {}
    )

    print()
    print("OVERALL STATUS")
    print("-" * 70)
    print(
        "Status:",
        overall.get("status")
    )
    print(
        "Reason:",
        overall.get("reason")
    )

    print_section(
        "FACTS",
        analysis.get(
            "facts",
            []
        )
    )

    print_section(
        "WARNINGS",
        analysis.get(
            "warnings",
            []
        )
    )

    print_section(
        "NOISE / EXPECTED EVENTS",
        analysis.get(
            "noise_expected_events",
            []
        )
    )

    print_section(
        "POTENTIAL CAUSES / HYPOTHESES",
        analysis.get(
            "potential_causes",
            []
        )
    )

    print_section(
        "PRIVILEGE ISSUES",
        analysis.get(
            "privilege_issues",
            []
        )
    )

    print()
    print("=" * 70)
    print("RECOMMENDED READ-ONLY INVESTIGATIONS")
    print("=" * 70)

    recommendations = analysis.get(
        "recommended_investigations",
        []
    )

    if not recommendations:

        print("None.")

    else:

        for index, item in enumerate(
            recommendations,
            start=1
        ):

            print()
            print(
                f"{index}. "
                f"{item.get('command_name')}"
            )

            print(
                "   Reason:",
                item.get("reason")
            )

            print(
                "   Risk:",
                item.get("risk")
            )

            print(
                "   Confidence:",
                item.get("confidence")
            )

            print(
                "   Evidence:",
                ", ".join(
                    item.get(
                        "evidence",
                        []
                    )
                )
            )

    print()
    print("=" * 70)
    print("END OF DIAGNOSTIC ANALYSIS")
    print("=" * 70)
