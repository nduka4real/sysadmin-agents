﻿def detect_linux_os(run_command):
    """
    Detect the Linux distribution using /etc/os-release.

    The SSH command function in tools.linux returns a dictionary,
    so this function extracts the command output safely.
    """

    result = run_command(
        "cat /etc/os-release 2>/dev/null"
    )

    # Handle the dictionary returned by run_ssh_command()
    if isinstance(result, dict):

        if "stdout" in result:
            output = result["stdout"]

        elif "output" in result:
            output = result["output"]

        elif "result" in result:
            output = result["result"]

        else:
            raise ValueError(
                "SSH command returned a dictionary, "
                "but no stdout/output/result field was found. "
                f"Available fields: {list(result.keys())}"
            )

    else:
        output = result

    if not isinstance(output, str):
        output = str(output)

    data = {}

    for line in output.splitlines():

        if "=" in line:

            key, value = line.split("=", 1)

            value = value.strip().strip('"')

            data[key.strip()] = value

    os_id = data.get("ID", "").lower()

    os_name = data.get("NAME", "")

    version = data.get("VERSION_ID", "")

    if os_id in (
        "ubuntu",
        "debian",
        "linuxmint",
        "pop",
    ):

        family = "debian"

    elif os_id in (
        "rhel",
        "rocky",
        "almalinux",
        "centos",
        "fedora",
        "ol",
        "oracle",
    ):

        family = "rhel"

    else:

        family = "unknown"

    return {
        "id": os_id,
        "name": os_name,
        "version": version,
        "family": family,
        "raw": output,
    }
