﻿"""
AI SysAdmin Command Registry
Day 3

Central registry of commands that the AI agent is allowed to request.

Current policy:
    READ_ONLY commands only.

No command in this file should modify, delete, restart,
stop, install, uninstall, or otherwise change the server.
"""


COMMAND_REGISTRY = {

    # ============================================================
    # COMMON LINUX SYSTEM INFORMATION
    # ============================================================

    "hostname": {
        "command": "hostname",
        "risk": "READ_ONLY",
        "description": "Get server hostname",
        "platform": "linux"
    },

    "uptime": {
        "command": "uptime",
        "risk": "READ_ONLY",
        "description": "Get server uptime",
        "platform": "linux"
    },

    "memory": {
        "command": "free -h",
        "risk": "READ_ONLY",
        "description": "Get memory usage",
        "platform": "linux"
    },

    "disk": {
        "command": "df -h",
        "risk": "READ_ONLY",
        "description": "Get filesystem usage",
        "platform": "linux"
    },

    "cpu": {
        "command": "lscpu",
        "risk": "READ_ONLY",
        "description": "Get CPU information",
        "platform": "linux"
    },

    "network": {
        "command": "ip addr",
        "risk": "READ_ONLY",
        "description": "Get network interfaces",
        "platform": "linux"
    },

    "ports": {
        "command": "ss -tulpn",
        "risk": "READ_ONLY",
        "description": "Get listening ports",
        "platform": "linux"
    },

    "failed_services": {
        "command": "systemctl --failed",
        "risk": "READ_ONLY",
        "description": "Get failed systemd services",
        "platform": "linux"
    },

    "system_errors": {
        "command": "journalctl -p err -b --no-pager",
        "risk": "READ_ONLY",
        "description": "Get current boot errors",
        "platform": "linux"
    },

    "os_release": {
        "command": "cat /etc/os-release",
        "risk": "READ_ONLY",
        "description": "Detect operating system",
        "platform": "linux"
    },


    # ============================================================
    # PROCESS INVESTIGATION
    # ============================================================

    "top_cpu_processes": {
        "command": "ps aux --sort=-%cpu | head -n 15",
        "risk": "READ_ONLY",
        "description": "Show processes using the most CPU",
        "platform": "linux"
    },

    "top_memory_processes": {
        "command": "ps aux --sort=-%mem | head -n 15",
        "risk": "READ_ONLY",
        "description": "Show processes using the most memory",
        "platform": "linux"
    },

    "detailed_memory_processes": {
        "command": (
            "ps -eo pid,ppid,user,%cpu,%mem,rss,vsz,"
            "stat,etime,comm --sort=-%mem | head -n 20"
        ),
        "risk": "READ_ONLY",
        "description": "Show detailed memory-consuming processes",
        "platform": "linux"
    },

    "detailed_cpu_processes": {
        "command": (
            "ps -eo pid,ppid,user,%cpu,%mem,rss,vsz,"
            "stat,etime,comm --sort=-%cpu | head -n 20"
        ),
        "risk": "READ_ONLY",
        "description": "Show detailed CPU-consuming processes",
        "platform": "linux"
    },

    "top_snapshot": {
        "command": "top -b -n 1 | head -n 25",
        "risk": "READ_ONLY",
        "description": "Capture a non-interactive top process snapshot",
        "platform": "linux"
    },

    "process_count": {
        "command": "ps -e --no-headers | wc -l",
        "risk": "READ_ONLY",
        "description": "Count running processes",
        "platform": "linux"
    },

    "load_average": {
        "command": "cat /proc/loadavg",
        "risk": "READ_ONLY",
        "description": "Get Linux load average",
        "platform": "linux"
    },

    "zombie_processes": {
        "command": (
            "ps -eo pid,ppid,user,stat,comm "
            "| awk '$4 ~ /Z/ {print}'"
        ),
        "risk": "READ_ONLY",
        "description": "Find zombie processes",
        "platform": "linux"
    },

    "process_state_summary": {
        "command": (
            "ps -eo stat= "
            "| cut -c1 "
            "| sort "
            "| uniq -c "
            "| sort -nr"
        ),
        "risk": "READ_ONLY",
        "description": "Summarize Linux process states",
        "platform": "linux"
    },

    "process_overview": {
        "command": (
            "ps -eo pid,ppid,user,stat,%cpu,%mem,comm "
            "--sort=-%mem | head -n 30"
        ),
        "risk": "READ_ONLY",
        "description": "Show general process overview",
        "platform": "linux"
    },


    # ============================================================
    # RHEL SECURITY / FIREWALL
    # ============================================================

    "selinux": {
        "command": "getenforce",
        "risk": "READ_ONLY",
        "description": "Check SELinux status",
        "platform": "rhel"
    },

    "selinux_status": {
        "command": "sestatus",
        "risk": "READ_ONLY",
        "description": "Get detailed SELinux status",
        "platform": "rhel"
    },

    "firewall": {
        "command": "firewall-cmd --state",
        "risk": "READ_ONLY",
        "description": "Check firewalld status",
        "platform": "rhel"
    },

    "firewall_rules": {
        "command": "firewall-cmd --list-all",
        "risk": "READ_ONLY",
        "description": "List firewalld configuration",
        "platform": "rhel"
    },


    # ============================================================
    # UBUNTU / DEBIAN FIREWALL
    # ============================================================

    "ufw": {
        "command": "ufw status",
        "risk": "READ_ONLY",
        "description": "Check UFW status",
        "platform": "debian"
    },


    # ============================================================
    # SYSTEM JOURNAL
    # ============================================================

    "journal": {
        "command": "journalctl -n 100 --no-pager",
        "risk": "READ_ONLY",
        "description": "View the most recent system journal entries",
        "platform": "linux"
    },

    "journal_errors": {
        "command": "journalctl -p err -n 100 --no-pager",
        "risk": "READ_ONLY",
        "description": "View recent journal errors",
        "platform": "linux"
    },

    "journal_warnings": {
        "command": "journalctl -p warning -n 100 --no-pager",
        "risk": "READ_ONLY",
        "description": "View recent journal warnings",
        "platform": "linux"
    },

    "current_boot": {
        "command": "journalctl -b 0 -n 100 --no-pager",
        "risk": "READ_ONLY",
        "description": "View current boot journal",
        "platform": "linux"
    },

    "previous_boot": {
        "command": "journalctl -b -1 -n 100 --no-pager",
        "risk": "READ_ONLY",
        "description": "View previous boot journal",
        "platform": "linux"
    },

    "kernel_errors": {
        "command": "dmesg --level=err,warn -T | tail -n 100",
        "risk": "READ_ONLY",
        "description": "View recent kernel errors and warnings",
        "platform": "linux"
    },


    # ============================================================
    # LOG FILES
    # ============================================================

    "auth_logs": {
        "command": "tail -n 100 /var/log/auth.log",
        "risk": "READ_ONLY",
        "description": "View authentication logs",
        "platform": "linux"
    },

    "log_files": {
        "command": (
            "find /var/log -maxdepth 2 "
            "-type f -print"
        ),
        "risk": "READ_ONLY",
        "description": "List Linux log files",
        "platform": "linux"
    },

    "log_sizes": {
        "command": (
            "du -sh /var/log/* 2>/dev/null | sort -h"
        ),
        "risk": "READ_ONLY",
        "description": "Show sizes of log directories and files",
        "platform": "linux"
    }
}


# ================================================================
# REGISTRY ACCESS FUNCTIONS
# ================================================================

def get_command(name):
    """
    Return a registered command definition.

    Raises:
        ValueError:
            If the command does not exist.
    """

    if name not in COMMAND_REGISTRY:
        raise ValueError(
            f"Command '{name}' is not in the approved registry."
        )

    return COMMAND_REGISTRY[name]


def list_commands():
    """
    Return the complete command registry.
    """

    return COMMAND_REGISTRY


def is_command_allowed(name):
    """
    Return True only when a command exists and is READ_ONLY.
    """

    if name not in COMMAND_REGISTRY:
        return False

    definition = COMMAND_REGISTRY[name]

    return definition["risk"] == "READ_ONLY"


def get_commands_for_platform(platform):
    """
    Return commands available to a specific platform.

    Example:

        get_commands_for_platform("rhel")

    returns commands marked as either:

        linux
        rhel
    """

    results = {}

    for name, definition in COMMAND_REGISTRY.items():

        if definition["platform"] in (
            "linux",
            platform
        ):
            results[name] = definition

    return results
