﻿def get_journal(run_command, lines=100):
    return run_command(
        f"journalctl -n {int(lines)} --no-pager"
    )


def get_current_boot_journal(run_command, lines=100):
    return run_command(
        f"journalctl -b 0 -n {int(lines)} --no-pager"
    )


def get_previous_boot_journal(run_command, lines=100):
    return run_command(
        f"journalctl -b -1 -n {int(lines)} --no-pager"
    )


def get_journal_errors(run_command, lines=100):
    return run_command(
        f"journalctl -p err -n {int(lines)} --no-pager"
    )


def get_journal_warnings(run_command, lines=100):
    return run_command(
        f"journalctl -p warning -n {int(lines)} --no-pager"
    )


def get_service_journal(run_command, service, lines=100):
    safe_service = service.replace("'", "")
    return run_command(
        f"journalctl -u '{safe_service}' "
        f"-n {int(lines)} --no-pager"
    )


def get_auth_logs(run_command, lines=100):
    command = (
        "if [ -f /var/log/auth.log ]; then "
        f"tail -n {int(lines)} /var/log/auth.log; "
        "elif [ -f /var/log/secure ]; then "
        f"tail -n {int(lines)} /var/log/secure; "
        "else "
        "echo 'Authentication log file not found'; "
        "fi"
    )

    return run_command(command)


def list_log_files(run_command):
    return run_command(
        "find /var/log -maxdepth 2 "
        "-type f "
        "-printf '%p\\t%s bytes\\n' "
        "2>/dev/null | sort"
    )


def get_log_sizes(run_command):
    return run_command(
        "du -sh /var/log/* 2>/dev/null | sort -h"
    )


def get_log_directories(run_command):
    return run_command(
        "find /var/log -maxdepth 2 "
        "-type d "
        "-print "
        "2>/dev/null | sort"
    )


def search_logs(run_command, pattern, lines=100):
    safe_pattern = pattern.replace("'", "")

    command = (
        "grep -Rni "
        f"-- '{safe_pattern}' "
        "/var/log "
        "2>/dev/null "
        f"| head -n {int(lines)}"
    )

    return run_command(command)


def get_recent_errors(run_command, lines=100):
    return run_command(
        f"journalctl -p 0..3 -n {int(lines)} --no-pager"
    )


def get_kernel_messages(run_command, lines=100):
    return run_command(
        f"dmesg --level=err,warn -T "
        f"| tail -n {int(lines)}"
    )
