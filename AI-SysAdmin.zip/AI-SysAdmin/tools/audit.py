﻿import os
from datetime import datetime


PROJECT_ROOT = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)


LOG_DIRECTORY = os.path.join(
    PROJECT_ROOT,
    "logs"
)


LOG_FILE = os.path.join(
    LOG_DIRECTORY,
    "agent_audit.log"
)


def ensure_log_directory():

    os.makedirs(
        LOG_DIRECTORY,
        exist_ok=True
    )


def write_audit(
    action,
    risk,
    status,
    details=""
):

    ensure_log_directory()

    timestamp = datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )

    entry = (
        f"[{timestamp}]\n"
        f"ACTION: {action}\n"
        f"RISK: {risk}\n"
        f"STATUS: {status}\n"
        f"DETAILS: {details}\n"
        f"{'-' * 60}\n"
    )

    with open(
        LOG_FILE,
        "a",
        encoding="utf-8"
    ) as file:

        file.write(entry)


def get_audit_log():

    ensure_log_directory()

    if not os.path.exists(LOG_FILE):
        return ""

    with open(
        LOG_FILE,
        "r",
        encoding="utf-8"
    ) as file:

        return file.read()
