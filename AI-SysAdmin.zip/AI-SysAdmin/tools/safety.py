﻿from tools.command_registry import get_command


ALLOWED_RISKS = {
    "READ_ONLY"
}


def validate_command(command_name):

    try:

        command = get_command(command_name)

    except ValueError as error:

        return {
            "allowed": False,
            "reason": str(error),
            "risk": "UNKNOWN"
        }

    risk = command["risk"]

    if risk not in ALLOWED_RISKS:

        return {
            "allowed": False,
            "reason": (
                f"Command risk '{risk}' is not currently "
                "allowed by the safety policy."
            ),
            "risk": risk
        }

    return {
        "allowed": True,
        "reason": "Command is approved for execution.",
        "risk": risk
    }


def require_safe_command(command_name):

    result = validate_command(command_name)

    if not result["allowed"]:

        raise PermissionError(
            f"BLOCKED: {command_name} - "
            f"{result['reason']}"
        )

    return True
