import paramiko


def run_ssh_command(host, username, password, command):

    client = paramiko.SSHClient()

    client.set_missing_host_key_policy(
        paramiko.AutoAddPolicy()
    )

    try:

        client.connect(
            hostname=host,
            username=username,
            password=password,
            timeout=10
        )

        stdin, stdout, stderr = client.exec_command(
            command
        )

        output = stdout.read().decode(
            "utf-8",
            errors="replace"
        )

        error = stderr.read().decode(
            "utf-8",
            errors="replace"
        )

        return {
            "success": True,
            "output": output,
            "error": error
        }

    except Exception as e:

        return {
            "success": False,
            "output": "",
            "error": str(e)
        }

    finally:

        client.close()


def get_hostname(host, username, password):

    return run_ssh_command(
        host,
        username,
        password,
        "hostname"
    )


def get_uptime(host, username, password):

    return run_ssh_command(
        host,
        username,
        password,
        "uptime"
    )


def get_memory(host, username, password):

    return run_ssh_command(
        host,
        username,
        password,
        "free -h"
    )


def get_disk(host, username, password):

    return run_ssh_command(
        host,
        username,
        password,
        "df -h"
    )


def get_cpu(host, username, password):

    return run_ssh_command(
        host,
        username,
        password,
        "lscpu"
    )


def get_network(host, username, password):

    return run_ssh_command(
        host,
        username,
        password,
        "ip addr"
    )


def get_listening_ports(host, username, password):

    return run_ssh_command(
        host,
        username,
        password,
        "ss -tulpn"
    )


def get_failed_services(host, username, password):

    return run_ssh_command(
        host,
        username,
        password,
        "systemctl --failed"
    )


def get_system_errors(host, username, password):

    return run_ssh_command(
        host,
        username,
        password,
        "journalctl -p err -b --no-pager -n 50"
    )