﻿"""
Linux Process Investigation Tools
AI SysAdmin Course - Day 3

All functions in this module are READ_ONLY.

This module investigates:
- Top CPU-consuming processes
- Top memory-consuming processes
- Detailed process information
- Process count
- Load average
- Zombie processes
- Individual process details
- Memory summary
- Non-interactive top snapshot
"""


def get_top_cpu_processes(run_command, lines=15):
    """
    Return processes consuming the most CPU.
    """
    lines = int(lines)

    return run_command(
        f"ps aux --sort=-%cpu | head -n {lines}"
    )


def get_top_memory_processes(run_command, lines=15):
    """
    Return processes consuming the most memory.
    """
    lines = int(lines)

    return run_command(
        f"ps aux --sort=-%mem | head -n {lines}"
    )


def get_detailed_memory_processes(run_command, lines=20):
    """
    Return detailed information about memory-consuming processes.
    """
    lines = int(lines)

    return run_command(
        "ps -eo "
        "pid,ppid,user,%cpu,%mem,rss,vsz,stat,etime,comm "
        f"--sort=-%mem | head -n {lines}"
    )


def get_detailed_cpu_processes(run_command, lines=20):
    """
    Return detailed information about CPU-consuming processes.
    """
    lines = int(lines)

    return run_command(
        "ps -eo "
        "pid,ppid,user,%cpu,%mem,rss,vsz,stat,etime,comm "
        f"--sort=-%cpu | head -n {lines}"
    )


def get_top_command(run_command):
    """
    Capture a non-interactive snapshot of the top command.

    -b = batch mode
    -n 1 = one iteration
    """
    return run_command(
        "top -b -n 1 -o %CPU | head -n 25"
    )


def get_process_count(run_command):
    """
    Return the number of running processes.
    """
    return run_command(
        "ps -e --no-headers | wc -l"
    )


def get_load_average(run_command):
    """
    Return Linux load-average information.
    """
    return run_command(
        "cat /proc/loadavg"
    )


def get_zombie_processes(run_command):
    """
    Find zombie processes.

    An empty result normally means no zombie processes
    were found.
    """
    return run_command(
        "ps -eo pid,ppid,user,stat,comm "
        "| awk '$4 ~ /Z/ {print}'"
    )


def get_process_by_pid(run_command, pid):
    """
    Return detailed information about a specific PID.

    PID is converted to an integer to prevent arbitrary
    shell input from being passed to the remote server.
    """
    pid = int(pid)

    return run_command(
        "ps -p "
        f"{pid} "
        "-o pid,ppid,user,%cpu,%mem,rss,vsz,"
        "stat,etime,lstart,cmd"
    )


def get_memory_summary(run_command):
    """
    Return total, used, available and swap memory.
    """
    return run_command(
        "free -h"
    )


def get_cpu_summary(run_command):
    """
    Return CPU information.
    """
    return run_command(
        "lscpu"
    )


def get_process_state_summary(run_command):
    """
    Return a summary of process states.
    """
    return run_command(
        "ps -eo stat= "
        "| cut -c1 "
        "| sort "
        "| uniq -c "
        "| sort -nr"
    )


def get_process_tree(run_command, lines=30):
    """
    Return a read-only process tree.
    """
    lines = int(lines)

    return run_command(
        f"ps -eo pid,ppid,user,stat,%cpu,%mem,comm "
        f"--sort=-%mem | head -n {lines}"
    )


def get_high_memory_processes(
    run_command,
    threshold=10,
    lines=20
):
    """
    Find processes using at least the specified percentage
    of memory.

    Example:
        threshold=10

    means processes using >= 10 percent memory.
    """
    threshold = float(threshold)
    lines = int(lines)

    return run_command(
        "ps -eo pid,ppid,user,%cpu,%mem,rss,vsz,stat,etime,comm "
        f"| awk 'NR==1 || $5 >= {threshold}' "
        f"| head -n {lines}"
    )


def get_high_cpu_processes(
    run_command,
    threshold=50,
    lines=20
):
    """
    Find processes using at least the specified percentage
    of CPU.

    Example:
        threshold=50

    means processes using >= 50 percent CPU.
    """
    threshold = float(threshold)
    lines = int(lines)

    return run_command(
        "ps -eo pid,ppid,user,%cpu,%mem,rss,vsz,stat,etime,comm "
        f"| awk 'NR==1 || $4 >= {threshold}' "
        f"| head -n {lines}"
    )